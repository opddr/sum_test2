#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{

	FILE * fp = NULL;


	if(argc < 3)
	{
		printf("USAGE : %s '[FILE_NAME]' '[STRING]' \n",argv[0]);
		 return 0;
	}
	else
	{	
		char FILE_NAME[100]= {0,};
		strncpy(FILE_NAME,argv[1],100);

		fp = fopen(FILE_NAME,"w+");

		if(fp) 
		{
			fprintf(fp,"%s\n",argv[2]);
			fclose(fp);
		}
		else
		{
			printf("CAN NOT OPEN FILE \n");
		}
		
	}


return 0;
}
