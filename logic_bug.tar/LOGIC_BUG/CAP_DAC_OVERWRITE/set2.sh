#!/bin/sh
sudo setcap cap_dac_override+eip ./USER_BIN
getcap ./USER_BIN

