#!/bin/sh
chown guest:guest ./USER_BIN
chmod 755 ./USER_BIN
chown guest:guest ./USER_BIN.c
chmod 766 ./USER_BIN.c
chown root:root ./ROOT_FILE
chmod 744 ./ROOT_FILE

