#!/bin/sh

echo "/sys/kernel/uevent_helper"

echo "`pwd`/R_CONNECTION.sh" > /sys/kernel/uevent_helper

echo “change” > /sys/class/mem/null/uevent_helper
echo "change" > /sys/device/virtual/mem/null/uevent 


echo "Real Ubuntu machine test"

