#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
int main()
{

	socket(AF_SECURITY,SOCK_STREAM,0);



return 0;
}
