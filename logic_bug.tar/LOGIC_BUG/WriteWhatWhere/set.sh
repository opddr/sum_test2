#!/bin/sh
echo 'cat /proc/sys/kernel/modprobe'
cat /proc/sys/kernel/modprobe
echo ''

echo 'cat ./R_CONNECTION.sh'
cat ./R_CONNECTION.sh

echo ''

echo 'chmod 777 ./R_CONNECTION.sh'
chmod 777 ./R_CONNECTION.sh

echo ''
echo ''

echo '[TODO]sudo su -  && write modprobe' 

