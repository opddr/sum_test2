#!/bin/sh

echo 'touch /tmp/DST_FILE'
echo '' 
touch /tmp/DST_FILE
chown root:root /tmp/DST_FILE
chmod 744 /tmp/DST_FILE

echo 'ln -s /tmp/DST_FILE /tmp/SRC_FILE.lnk'

ln -s /tmp/DST_FILE /tmp/SRC_FILE.lnk

