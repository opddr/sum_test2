#!/bin/sh
echo 'sudo sysctl -A |grep symlink'

sysctl -A | grep symlink

echo ''

echo '[TODO] sysctl -w fs.protected_symlinks=0'
